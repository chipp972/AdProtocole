package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

import utils.Ad;
import utils.Transaction;
import client.PeerListener;

public class AdClient extends Thread {
	/* Données serveur */
	public static final String LOCAL_SERVER = "localhost";
	public static final int PORT_SERVER = 1027;
	private static volatile LinkedList<Ad> adList = new LinkedList<Ad>();

	/* Communication avec le serveur */
	private Socket servSock;
	private DataInputStream in;
	private DataOutputStream out;
	private Scanner userIn;
	private ServerListener sl;
	private boolean end;

	/* Communication avec les clients */
	private DatagramSocket udpSock;
	private DatagramPacket dp;
	private LinkedList<String> msgList;
	private LinkedList<Transaction> transacList;
	private PeerListener pl;

	/* Constructeur */
	public AdClient() {
		userIn = new Scanner(System.in);
		end = false;
		msgList = new LinkedList<String>();
		transacList = new LinkedList<Transaction>();

		try {
			udpSock = new DatagramSocket();
		} catch (SocketException e) {
			e.printStackTrace();
			System.exit(0);
		}
		pl = new PeerListener(udpSock);
		pl.setDaemon(true);
	}

	/* transacListhodes concernants le serveur */
	public void connexion(Socket s) throws IOException {
		this.servSock = s;
		in = new DataInputStream(servSock.getInputStream());
		out = new DataOutputStream(servSock.getOutputStream());
		sl = new ServerListener(in, this);

		System.out.println("Client connecte au serveur "+ servSock);
	}

	/* Envoie la String s au serveur */
	public void sendServer(String s) {
		try {
			out.writeUTF(s);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/* Imprimme la liste des annonces récupérées sur la sortie standard */
	synchronized public void listAds() {
		Iterator<Ad> it = adList.iterator();
		if (adList.isEmpty()) {
			System.out.println("Aucune annonce sur le serveur.");
		} else {
			while(it.hasNext())
				System.out.println(it.next().toClientOutput());
		}
	}

	/* Imprimme la liste des messages des clients */
	public void listMsg() {
		Iterator<String> it = msgList.iterator();
		if (msgList.isEmpty()) {
			System.out.println("Aucun message de clients.");
		} else {
			while (it.hasNext()) {
				System.out.println(it.next());
			}
		}
	}

	/* Imprimme la liste des transactions proposées par les clients */
	public void listTransac() {
		Iterator<Transaction> it = transacList.iterator();
		if (transacList.isEmpty()) {
			System.out.println("Aucune transaction proposée.");
		} else {
			while (it.hasNext())
				System.out.println(it.next().toString());
		}
	}


	synchronized public void addAd(Ad a) {
		adList.add(a);
	}

	synchronized public void delAd(String id) {
		Iterator<Ad> it = adList.iterator();
		Ad a;
		while(it.hasNext()) {
			a = it.next();
			if(a.getAdId().equals(id)) {
				it.remove();
				break;
			}
		}
	}

	/* Ferme les buffers de lecture, d'écriture, le scanner et la socket */
	public void closeConnexion() {
		try {
			in.close();
			out.close();
			userIn.close();
			servSock.close();
		} catch (IOException e) {
			System.out.println("Erreur en fermant la communication.");
			e.printStackTrace();
		}
	}

	public void endCommunication() {
		end = true;
	}

	/* Méthodes concernants les clients */
	public void sendClient(int adId, String messageType, String message) {
		// retrouver l'annonce dans adList qui correspond à l'adId donné
		String msg;
		byte [] buf;
		switch (messageType) {
			case "msg":
			// TODO udp server send "AD\r\nID tokenize1\r\nchoice.substring(last index tokenize1)"
			break;
			case "ask":
			break;
			case "ok":
			break;
			case "ko":
			break;
			default:
				System.out.println("Type de message inconnu");
				return;
		}
		try {
			buf = msg.getBytes();
			// dp = new DatagramPacket(buf, message.length(), a.getClientInfo.getIp(), a.getClientInfo.getPort());
			udpSock.send(dp);
		} catch(IOException e) {
			System.out.println("Erreur lors de l'envoie au client "+dp.getAddress());
		}
	}

	private void printCommands() {
		System.out.println("Ajout d'une annonce : ad <message de l'annonce>");
		System.out.println("Supression d'une annonce : rm <id-annonce>");
		System.out.println("Lister toutes les annonces : ls");

		System.out.println("Envoyer un message a un client : ms <id-annonce> <message>");
		System.out.println("Afficher les messages des clients : sm");
		System.out.println("Afficher les demandes de transaction : st");
		System.out.println("Demander de conclure une transaction : ct <id-annonce>");
		System.out.println("Accepter une transaction : ok <id-transaction>");
		System.out.println("Refuser une transaction : ko <id-transaction>");
		System.out.println("Afficher cette aide : help");
		System.out.println("Deconnexion : exit");
	}

	public void run() {
		String choice = "";
		// Envoie du port UDP
		sendServer("USR\r\nPORT "+udpSock.getLocalPort()+"\r\n");
		printCommands();
		sl.start(); // on lance le thread qui écoute le serveur
		pl.start(); // on lance le thread qui écoute les clients
		while(userIn.hasNextLine() && !end) {
			choice = userIn.nextLine();
			if(choice.length() > 0) {
				switch(choice.substring(0, 2)) {
				case "ad":
					if(choice.length() > 3)
						sendServer("AD\r\nADD\r\nMSG "+choice.substring(3).trim()+"\r\n");
				break;
				case "rm":
					if(choice.length() > 3)
						sendServer("AD\r\nDEL\r\nID "+choice.substring(3).trim()+"\r\n");
				break;
				case "ls":
					listAds();
				break;
				case "ms":
					//TODO sendClient...
				break;
				case "as":
					// TODO udp server send "AD QUERY choice.substring(4)"
				break;
				case "sw":
					listMsg();
				break;
				case "st":
					listTransac();
				break;
				case "ct":
				break;
				case "ok":
					// TODO udp server send "AD ACCEPT choice.substring(3)"
					sendServer("AD\r\nDEL\r\nID "+choice.substring(3).trim()+"\r\n");
				break;
				case "ko":
					// TODO udp server send "AD REFUSE choice.substring(3)"
					sendServer("AD\r\nDEL\r\nID "+choice.substring(3).trim()+"\r\n");
				break;
				case "ex":
					end = true;
					sendServer("DISCONNECT\r\n");
				break;
				case "he":
					printCommands();
				break;
				default:
					System.out.println("Choix invalide.");
					printCommands();
				}
			}
		}
		sl.close();
		pl.close();
		closeConnexion();
	}

	public static void main(String args[]) {
		AdClient c = null;
		try {
			if(args.length == 0) { //Sur la même machine
				c = new AdClient();
				c.connexion(new Socket(LOCAL_SERVER, PORT_SERVER));

			} else if(args.length == 1) { //Sur le réseau local
				c = new AdClient();
				c.connexion(new Socket(args[0], PORT_SERVER));

			} else {
				System.out.println("Usage 1 : java -jar client.jar");
				System.out.println("Usage 2 : java -jar client.jar Server-address");
				System.exit(0);
			}

			c.start();
			c.join();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Le serveur n'est pas exécuté. Fermeture du client.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
